/*this program can let user know the different television
type and size and connection mode*/
#include <iostream>
#include <string>
using namespace std;
class Television {
private:
	string displayType;// display TV type
	double dimension;//Size of the TV in inches
	string* connectivitySupport;// Number of connection modes
	int connectivitycount;// Supported connection mode (dynamic memory)
public:
	Television();
	Television(string,double,string*,int);
	Television(const Television& other);
	~Television() { delete[] connectivitySupport;}
	Television& operator=(const Television& other);
	string getdisplay() const{ return displayType; }
	double getdimension() const{ return dimension; }
	string* gstconnectivitySupport() const{ return connectivitySupport; }
	int getconnectivitycount() const{ return connectivitycount; }
	void setdisplayType(string type){ displayType = type; }
	void setdimension(double dim) { dimension = dim; }
	void setconnectivitysupport(string* connectivity,int count){
		delete[] connectivitySupport;
		connectivitycount = count;
		connectivitySupport = new string[connectivitycount];
		for (int i = 0; i < connectivitycount; i++) {
			connectivitySupport[i] = connectivity[i];
		}
	}
	void displayInfo()const{
		cout << "Display Type:" << displayType << endl;;
		cout << "Dimension:" << dimension<<" inches " << endl;
		cout << "Connectivity support:";
		for (int i = 0; i < connectivitycount; i++) {
			cout << connectivitySupport[i] << " ";
		}
		cout << endl;
	}
};
int main(void) {
	string displayType; // display TV type
	double dimension;//Size of the TV in inches
	int connectivityCount;// Number of connection modes
	string* connectivitySupport;// Supported connection mode (dynamic memory)
	int num_of_tel;
	cout << "Please enter the televsion type" << endl;
	getline(cin, displayType);
	cout << "Please enter the televsion dimension(inch)" << endl;
	cin >> dimension;
	cout << "Please enter the connectivitycount" << endl;
	cin >> connectivityCount;
	cin.ignore();
	connectivitySupport = new string[connectivityCount];
	for (int i = 0; i < connectivityCount; i++) {
		cout << "Please enter the " << i + 1 << " connectivitysupport: ";
		getline(cin, connectivitySupport[i]);
	}
	Television defaultTv(displayType, dimension, connectivitySupport, connectivityCount);
	delete[] connectivitySupport;
	cout << "Pleasse enter the number of television" << endl;
	cin >> num_of_tel;
	cin.ignore();
	Television* television = new Television[num_of_tel];
	for (int i = 0; i < num_of_tel; i++) {
		television[i] = defaultTv;
	}
	for (int i = 0; i < num_of_tel; ++i) {
		char customize;
		cout << "would you want to define the " << i + 1 << " television?(y/n)";
		cin >> customize;
		cin.ignore();
		if (customize == 'y'||customize=='Y') {
			cout << "Please enter the televsion type" << endl;
			getline(cin, displayType);
			cout << "Please enter the televsion dimension(inch)" << endl;
			cin >> dimension;
			cin.ignore();
			cout << "Please enter the connectivitycount" << endl;
			cin >> connectivityCount;
			cin.ignore();
			connectivitySupport = new string[connectivityCount];
			for (int j = 0; j < connectivityCount; j++) {
				cout << "Please enter the " << j + 1 << " connectivitysupport: ";
				getline(cin, connectivitySupport[j]);
			}
			television[i].setdisplayType(displayType);
			television[i].setdimension(dimension);
			television[i].setconnectivitysupport(connectivitySupport,connectivityCount);
			delete[] connectivitySupport;
		}
	}
	for (int i = 0; i < num_of_tel; i++) {
		cout << "The " << i + 1 << " television" << endl;
		television[i].displayInfo();
	}
	delete[] television;
	return 0;
}
Television::Television():displayType(""),dimension(0.0),connectivitySupport(nullptr), connectivitycount(0) {}
Television::Television(string type, double dim, string* connectivity, int count)
	:displayType(type), dimension(dim), connectivitycount(count) {
	connectivitySupport = new string[connectivitycount];
	for (int i = 0; i < connectivitycount; i++) {
		connectivitySupport[i] = connectivity[i];
	}
}
//copy constructor
Television::Television(const Television& other) 
	:displayType(other.displayType), dimension(other.dimension), connectivitycount(other.connectivitycount) {
	connectivitySupport = new string[connectivitycount];
	for (int i = 0; i < connectivitycount; i++) {
		connectivitySupport[i] = other.connectivitySupport[i];
	}
}
Television& Television:: operator=(const Television& other) {
	if (this == &other) {
		return *this;
	}
	displayType = other.displayType;
	dimension = other.dimension;
	connectivitycount = other.connectivitycount;
	delete[] connectivitySupport;
	connectivitySupport = new string[connectivitycount];
	for (int i = 0; i < connectivitycount; i++) {
		connectivitySupport[i] = other.connectivitySupport[i];
	}
	return *this;
}







