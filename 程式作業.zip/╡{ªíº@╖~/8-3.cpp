/*used the friend function to test the 
each operator(+,=,*,==,<<,>>)*/
#include <iostream>

using namespace std;
class complex {
public:
	complex(double, double);
	complex(double realpart);
	complex();
	double getreal();
	double getimag();

	friend bool operator ==(const complex& number1,const complex& number2);
	friend const complex operator+(const complex& number1, const complex& number2);
	friend const complex operator-(const complex& number1, const complex& number2);
	friend const complex operator*(const complex& number1, const complex& number2);
	friend ostream& operator <<(ostream& outputstream, const complex& number2);
	friend istream& operator >>(istream& inputstream, complex& number2);


private:
	double real, imaginary;
};
const complex i(0, 1);

int main(void) {
	/*Testing the constructors*/ 
	complex first, second(20, 50), third(3), fourth;
	cout << "\nDefault constructor complex :" << first.getreal() << " " << first.getimag() << endl;
	cout << "\nTwo double constructor complex: " << second.getreal() << " " << second.getimag() << endl;
	cout << "\nOne double constructor complex: " << third.getreal() << " " << third.getimag() << endl;
	/*Testing the overloaded operators*/
	fourth = second + third;
	cout << "\nAdding second and third complex: " << fourth.getreal() << " " << fourth.getimag() << endl;
	fourth = second - third;
	cout << "\nSubtracting second and third complex: " << fourth.getreal() << " " << fourth.getimag() << endl;
	fourth = second * third;
	cout << "\nMultiplying second and third complex: " << fourth.getreal() << " " << fourth.getimag() << endl;
	cout << "\nDisplaying complex numbers with cout: " << endl << first << endl << second << endl << third << endl << fourth;
	cout << endl << complex(10, -10);
	return 0;
}
complex::complex(double r, double i) {
	real = r;
	imaginary = i;
}
complex::complex(double realpart) {
	real = realpart;
	imaginary =0;
}
complex::complex() {
	real = 0;
	imaginary = 0;
}
double complex::getreal() {
	return real;
}
double complex::getimag() {
	return imaginary;
}
bool operator ==(const complex& number1, const complex& number2) {
	return (number1.real == number2.real && number1.imaginary == number2.imaginary);
}
const complex operator+(const complex& number1, const complex& number2) {
	double realpart = number1.real + number2.real;
	double imaginarypart = number1.imaginary + number2.imaginary;
	return complex(realpart, imaginarypart);
}
const complex operator-(const complex& number1, const complex& number2) {
	double realpart = number1.real - number2.real;
	double imaginarypart = number1.imaginary - number2.imaginary;
	return complex(realpart, imaginarypart);
}
const complex operator*(const complex& number1, const complex& number2) {
	double firstTerm = number1.real*number2.real - number1.imaginary*number2.imaginary;
	double secondTerm = (number1.real*number2.imaginary+number2.real*number1.imaginary)*i.imaginary;
	return complex(firstTerm, secondTerm);
}
ostream& operator <<(ostream& outputstream, const complex& number2) {
	if (number2.imaginary >= 0) {
		outputstream << number2.real << "+" << number2.imaginary << "i";
	}
	else {
		outputstream << number2.real << number2.imaginary << "i";
	}
	return outputstream;
}
istream& operator >>(istream& inputstream, complex& number) {
	char sign,i;
	inputstream >> number.real >> sign;
	if (sign == '+' || sign == '-') {
		inputstream >> number.imaginary;
		if (sign == '-') {
			number.imaginary *= -1;
		}
	}
	else {
		cout << "No sign detected";
		exit(1);
	}
	return inputstream;

}