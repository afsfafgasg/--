/*used class and test the operator(++,--)*/
#include <iostream>
#include <cmath>
using namespace std;
// Takes no input, problem sets 1 as default value
// for default construtor
class PrimeNumber {

public:
	PrimeNumber() { prime = 1; }
	PrimeNumber(int);
	int getprimenum() { return prime; }
	PrimeNumber operator ++();
	PrimeNumber operator ++(int);
	PrimeNumber operator --();
	PrimeNumber operator --(int);
	friend ostream& operator <<(ostream&,const PrimeNumber&);

private:
	int prime;
	bool isprime(int);
};


int main(void) {
	PrimeNumber a;
	cout << "Default constructor PrimeNumber, a: " << a;
	cout << "Using prefix -- on a: " << --a;
	PrimeNumber b(13);
	cout << "The next prime number from b is: " << ++b;
	cout << "The next prime number from b is: " << ++b;

	PrimeNumber c(19);
	cout << "The first prefix prime number from c is: " << --c;
	cout << "The second prefix prime number from c is: " << --c;
	return 0;
}
PrimeNumber::PrimeNumber(int num) {
	if (isprime(num)) {
		prime = num;
	}
	else {
		prime = 2;
	}
}
PrimeNumber PrimeNumber:: operator ++() {
	int temp;
	temp = prime + 1;
	while (!isprime(temp)) {
		temp += 1;
	}
	prime = temp;
	return PrimeNumber(temp);
}
PrimeNumber PrimeNumber:: operator ++(int num) {
	int orig_num = prime, next_num = prime + 1;
	while (!isprime(next_num)) {
		next_num += 1;
	}
	prime = next_num;
	return PrimeNumber(orig_num);
}

PrimeNumber PrimeNumber:: operator --() {
	int orig_num = prime, temp = prime - 1;
	if (orig_num == 1) {
		return PrimeNumber();
	}
	while (!isprime(temp)&&temp>1) {
		temp -= 1;
	}
	prime = temp;
	return PrimeNumber(temp);
}
PrimeNumber PrimeNumber:: operator --(int num) {
	int orig_num = prime, temp = prime - 1;
	if (orig_num == 1) {
		return PrimeNumber();
	}
	while (!isprime(temp) && temp > 1) {
		temp -= 1;
	}
	prime = temp;
	return PrimeNumber(orig_num);
}

ostream& operator <<(ostream& out, const PrimeNumber& num) {
	out << num.prime << endl;
	return out;
}

bool PrimeNumber::isprime(int num) {
	int temp = 2;
	bool flag = true;
	if (num < 2) {
		flag = false;
	}
	else {
		while (temp<=floor(sqrt(num))&& num>1){
			if ((num % temp) == 0) {
				flag = false;
				break;
			}
			temp += 1;
		}
	}
	return flag;
}
