/*used class which have name ,number of channels and channel list*/
#include <iostream>
#include <string>
#include <vector>
using namespace std;
class Subscriber {
private:
	string name;
	int numChannels;
	vector<string> channelList;
public:
	Subscriber();// Default constructor
	Subscriber(const string& subscriberName);// Parameterized constructor
	Subscriber(const Subscriber& otherName);// Copy constructor
	string getname() { return name; } // Accessors
	int getchannelnum() { return numChannels; } // Accessors
	vector<string> getchannelList() { return channelList; }
	~Subscriber(){}// Destructor
	void setname(const string& subscribername);
	void addchannel(const string& channelName);
	void clearchannel();
	void inputvalue(); // Input function
	void outputvalue () const;// Output function
	void reset();
	Subscriber& operator=(const Subscriber& other);
};
int main(void) {
	Subscriber subscriber1;
	subscriber1.inputvalue();
	subscriber1.outputvalue();
	Subscriber subscriber2("Tony");
	subscriber2.addchannel("sport");
	subscriber2.addchannel("school");
	subscriber2.outputvalue();
	subscriber2 = subscriber1;
	subscriber2.outputvalue();
	return 0;
}
Subscriber::Subscriber() : name(""), numChannels(0), channelList() {};
Subscriber::Subscriber(const string& subscriberName) : name(subscriberName), numChannels(0), channelList() {};
// Copy constructor
Subscriber::Subscriber(const Subscriber& otherName) {
	name = otherName.name;
	numChannels=otherName.numChannels;
	channelList=otherName.channelList;
}
void Subscriber::setname(const string& subscribername) {
	name = subscribername;
}
void Subscriber::addchannel(const string& channelName) {
	channelList.push_back(channelName);
	numChannels = channelList.size();
}
void Subscriber::clearchannel() {
	channelList.clear();
	numChannels = 0;
}
void Subscriber::inputvalue() {
	cout << "Enter subscriber name: ";
	getline(cin, name);
	cout << "Enter the number of channels: ";
	cin >> numChannels;
	cin.ignore();//To ignore the newline character left in the input buffer
	channelList.clear();
	for (int i = 0; i < numChannels; i++) {
		string channelname;
		cout << "Enter the channel name " << i + 1 << ": ";
		getline(cin, channelname);
		channelList.push_back(channelname);
	}
}
void Subscriber::outputvalue()const {
	cout << "Subscriber Name: " << name << "\n";
	cout << "Subscribed Channels (" << numChannels << "):\n";
	for (const auto& channel : channelList) {
		cout << "-" << channel << endl;
	}
}
void Subscriber::reset() {
	name = "";
	numChannels = 0;
	channelList.clear();
}
Subscriber& Subscriber:: operator=(const Subscriber& other) {
	if (this != &other) {
		name = other.name;
		numChannels = other.numChannels;
		channelList = other.channelList;
	}
	return *this;
}