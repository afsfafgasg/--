// Function to replace four-letter words with "love" or "Love"
#include <iostream>
#include <vector>
#include <sstream>
using namespace std;
string replace_word(string sentence);

int main(void) {
	string input_sentence;
	string output_sentence;
	while (true) {
		cout << "Please input one sentence(if want to leave input (quit))";
		getline(cin, input_sentence);
		if (input_sentence == "quit") {
			break;
		}
		// Replace four-letter words and print the result
		output_sentence = replace_word(input_sentence);
		cout << "After change sentence is: " << output_sentence << endl;
	}
	return 0;
}
string replace_word(string sentence) {
	istringstream ins(sentence);
	string word;
	vector<string>words;
	// Take the input sentence
	while (ins >> word) {
		// Check if the word has four letters and consists of alphabets only
		if (word.length() == 4 && isalpha(word[0]) && isalpha(word[1]) && isalpha(word[2]) && isalpha(word[3])) {
			// Replace the word with "love" or "Love" based on capitalization
			if (isupper(word[0])) {
				words.push_back("Love");
			}
			else {
				words.push_back("love");
			}
		}
		else {
			words.push_back(word);
		}
	}
	ostringstream ous;
	for (const auto& w : words) {
		ous << w << " ";
	}
	return ous.str();
}