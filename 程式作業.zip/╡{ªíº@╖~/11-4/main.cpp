/*main function*/
#include <iostream>
#include "Administrator.h"
#include "User.h"
using namespace std;
int main(void) {
	User user;
	Administrator administrator;
	if (user.Login("abbott", "monday")) {
		cout << "User login is successful" << endl;
	}
	else {
		cout << "User login is failed" << endl;
	}
	if (administrator.Login("abbott", "monday")) {
		cout << "Administrator login successful." << endl;
	}
	else {
		cout << "Administrator login is failed." << endl;
	}
	return 0;
}

