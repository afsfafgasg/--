//Administrator.h
#ifndef ADMINISTRATOR
#define ADMINISTRATOR
#include <string>
#include "security.h"
using namespace std;
class Administrator {
public:
	bool Login(string username,string password);
};
#endif

