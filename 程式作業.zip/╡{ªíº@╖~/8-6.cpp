/*Used the class and test operator []*/
#include <iostream>
using namespace std;
// Does not work with negative integers and takes no input
// Does not check if proper values
class MyInteger {
public:
	void setnumber(int num) { Number = num; };
	int getnumber() { return Number; };
	int operator[](int index);
private:
	int Number;
};
int main(void) {
	MyInteger integer;
	integer.setnumber(418);
	cout << "The number is ";
	cout << integer.getnumber() << endl;
	for (int i = 0; i < 5; i++) {
		cout << "The array " << i << " is ";
		cout << integer[i] << endl;;
	}
	return 0;
}
int MyInteger::operator[](int index) {
	int count=0,size=0 ;
	int temp=Number;
	bool validindex = false;
	if (temp == 0) {
		size = 1;
	}
	else {
		while (temp > 0) {
			temp /= 10;
			size += 1;
		}
	}
	temp = Number;
	while (temp >= 0 && count < size) {
		if (count == index) {
			temp %= 10;
			validindex = true;
			break;
		}
		temp /= 10;
		count += 1;
	}
	if (!validindex) {
		temp = -1;
	}
	return temp;
}